from app import create_app

# Create the Flask application using the factory
app = create_app()
