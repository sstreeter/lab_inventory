
from app import db

class Lab(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    computers = db.relationship('Computer', backref='lab', lazy=True)

class Computer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    identifier = db.Column(db.String(255), nullable=False)
    owner = db.Column(db.String(120), nullable=True)
    justification = db.Column(db.Text, nullable=True)
    lab_id = db.Column(db.Integer, db.ForeignKey('lab.id'), nullable=False)
